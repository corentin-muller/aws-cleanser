package main

//go:generate ./generate_mocks
